Please note that this is the combined product. Here both Wind seas and ocean swell is included. 
The wave power is the average of 20 years from the starting date of the simulations. 
